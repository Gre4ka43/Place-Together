"""Add the PlaceTogether window to the Linux application menu."""
import os
from pathlib import Path
import sys

if not sys.platform.startswith('linux'):
    raise SystemExit('This launcher installer is for Linux.')
if sys.version_info < (3, 12):
    raise SystemExit('Run this installer with Python 3.12 or newer.')
import tkinter

script = Path(__file__).resolve().parent.parent / 'server_desktop.py'
folder = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local/share') / 'applications'
folder.mkdir(parents=True, exist_ok=True)


def quote_exec(path):
    value = str(path).replace('%', '%%')
    for character in ('\\', '"', '`', '$'):
        value = value.replace(character, '\\' + character)
    return '"' + value.replace('\\', '\\\\') + '"'


entry = folder / 'placetogether-server.desktop'
entry.write_text(
    '[Desktop Entry]\nType=Application\nName=PlaceTogether Server\n'
    f'Exec={quote_exec(sys.executable)} {quote_exec(script)}\n'
    'Terminal=false\nCategories=Development;Network;\n',
    encoding='utf-8',
)
print(entry)
