#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
exec "${PT_PYTHON:-python3}" server_desktop.py
