@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul 2>&1
set "PLUGIN_DIR=%LOCALAPPDATA%\Roblox\Plugins"
set "PLUGIN_FILE=%PLUGIN_DIR%\PlaceTogether-Ultimate.rbxmx"
if not exist "%~dp0PlaceTogether.rbxmx" (
    echo ERROR: PlaceTogether.rbxmx is missing next to this installer.
    pause
    exit /b 1
)
if not exist "%PLUGIN_DIR%" mkdir "%PLUGIN_DIR%"
if exist "%PLUGIN_FILE%" copy /Y "%PLUGIN_FILE%" "%PLUGIN_FILE%.bak" >nul
copy /Y "%~dp0PlaceTogether.rbxmx" "%PLUGIN_FILE%"
if errorlevel 1 (
    echo Installation failed. Install the RBXMX manually in Studio.
    pause
    exit /b 1
)
echo Installed: %PLUGIN_FILE%
echo Disable previous PlaceTogether plugins and restart Roblox Studio.
pause
