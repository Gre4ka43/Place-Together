"""Explicit server-state component; instantiated by application.create_application."""
import uuid
import copy
import urllib.parse
import json
import os
import socket
import subprocess
import sys
import os
import json
import time
import hmac
import gzip
import shutil
import signal
import atexit
import hashlib
import difflib
import argparse
import threading
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

def install(state):

    class BodyTooLarge(Exception):
        pass
    state.BodyTooLarge = BodyTooLarge

    class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
        daemon_threads = True
        allow_reuse_address = True
        request_queue_size = 128
    state.ConcurrentServer = ThreadedHTTPServer

    class LegacyHandler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        timeout = 30

        def handle(self):
            try:
                super().handle()
            except (ConnectionResetError, ConnectionAbortedError, BrokenPipeError, TimeoutError):
                pass

        def log_message(self, format, *args):
            path = getattr(self, 'path', '')
            if any((p in path for p in ('/sync', '/presence', '/invitations', '/status', '/state', '/rooms'))):
                return
            sys.stderr.write('%s - - [%s] %s\n' % (self.address_string(), self.log_date_time_string(), format % args))

        def send_json(self, status_code, data):
            body = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            try:
                self.send_response(status_code)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                accept_encoding = self.headers.get('Accept-Encoding', '')
                if 'gzip' in accept_encoding and len(body) > 1024:
                    compressed = gzip.compress(body, compresslevel=6)
                    self.send_header('Content-Encoding', 'gzip')
                    self.send_header('Content-Length', str(len(compressed)))
                    out_body = compressed
                else:
                    self.send_header('Content-Length', str(len(body)))
                    out_body = body
                if state.cors_origin:
                    self.send_header('Access-Control-Allow-Origin', state.cors_origin)
                    self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                    self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-PT-Secret, bypass-tunnel-reminder')
                self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
                self.send_header('Connection', 'close' if self.close_connection else 'keep-alive')
                self.end_headers()
                self.wfile.write(out_body)
            except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                pass

        def do_OPTIONS(self):
            self.send_response(204)
            if state.cors_origin:
                self.send_header('Access-Control-Allow-Origin', state.cors_origin)
                self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
                self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-PT-Secret, bypass-tunnel-reminder')
            self.send_header('Content-Length', '0')
            self.end_headers()

        def get_token(self):
            auth = self.headers.get('Authorization', '')
            if auth.startswith('Bearer '):
                return auth[7:].strip()
            return None

        def secret_ok(self):
            """Optional server password (--secret / PT_SECRET)."""
            if not state.auth_secret:
                return True
            supplied = self.headers.get('X-PT-Secret', '')
            return hmac.compare_digest(str(supplied), state.auth_secret)

        def require_secret(self):
            if self.secret_ok():
                return True
            self.send_json(401, {'error': 'Неверный пароль сервера (X-PT-Secret)'})
            return False

        def require_guest(self, token):
            """Every room endpoint needs a registered guest token."""
            if token and token in state.guests:
                return True
            self.send_json(401, {'error': 'Нужна регистрация гостя. Переподключитесь к серверу.'})
            return False

        def read_body(self):
            raw_length = self.headers.get('Content-Length')
            try:
                content_length = int(raw_length or 0)
            except (TypeError, ValueError):
                raise ValueError('invalid Content-Length header')
            if content_length < 0:
                raise ValueError('negative Content-Length header')
            if content_length > state.MAX_BODY_BYTES:
                raise state.BodyTooLarge(f'body larger than {state.MAX_BODY_BYTES} bytes')
            if content_length == 0:
                return {}
            raw = self.rfile.read(content_length).decode('utf-8')
            if not raw.strip():
                return {}
            parsed = json.loads(raw)
            if isinstance(parsed, list):
                if len(parsed) == 0:
                    return {}
                raise ValueError('JSON body must be an object')
            if not isinstance(parsed, dict):
                raise ValueError('JSON body must be an object')
            return parsed

        def remember_client_revision(self, r, token, since_rev):
            """Track how far behind each connected peer is (drives tombstone pruning)."""
            clients = r.setdefault('clients', {})
            clients[token or 'anonymous'] = {'since': max(0, int(since_rev or 0)), 'time': time.time()}
            if len(clients) > 64:
                now = time.time()
                stale = [k for k, v in clients.items() if now - v.get('time', 0) > state.CLIENT_REV_TTL_SECONDS]
                for key in stale:
                    clients.pop(key, None)

        def compute_deltas_since(self, r, since_rev):
            deltas = {}
            for obj_id, rec in r['objects'].items():
                if rec.get('version', 0) > since_rev:
                    deltas[obj_id] = rec
            for obj_id, tomb in r.get('tombstones', {}).items():
                if tomb.get('version', 0) > since_rev:
                    deltas[obj_id] = {'version': tomb['version'], 'value': None}
            return deltas

        def send_dashboard_html(self):
            with state.lock:
                now = time.time()
                uptime_sec = int(now - state.server_start_time)
                h = uptime_sec // 3600
                m = uptime_sec % 3600 // 60
                s = uptime_sec % 60
                uptime_str = f'{h}h {m}m {s}s'
                rooms_list = []
                total_objs = 0
                for r_id, r in state.rooms.items():
                    obj_count = len(r.get('objects', {}))
                    total_objs += obj_count
                    peers = [p.get('name', 'Peer') for p in r.get('presence', {}).values() if now - p.get('time', 0) < 15]
                    rooms_list.append({'id': r_id, 'name': r.get('name', 'Studio Project'), 'revision': r.get('revision', 1), 'objects': obj_count, 'peers': peers, 'owner': r.get('owner_name', 'Host')})
                guests_list = [{'name': g.get('name', 'Guest'), 'token': t[:10] + '...', 'active': now - g.get('last_seen', 0) < 30} for t, g in state.guests.items()]
            html = f'<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1">\n<title>PlaceTogether 3.0 Live Dashboard</title>\n<style>\n  :root {{\n    --bg: #0d1117;\n    --card: #161b22;\n    --border: #30363d;\n    --text: #e6edf3;\n    --muted: #8b949e;\n    --accent: #58a6ff;\n    --green: #2ea043;\n    --red: #f85149;\n    --font: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;\n  }}\n  * {{ box-sizing: border-box; margin: 0; padding: 0; }}\n  body {{ background: var(--bg); color: var(--text); font-family: var(--font); padding: 24px; line-height: 1.5; }}\n  .container {{ max-width: 1080px; margin: 0 auto; }}\n  .header {{ display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid var(--border); }}\n  .title-group {{ display: flex; align-items: center; gap: 12px; }}\n  h1 {{ font-size: 24px; font-weight: 600; }}\n  .badge {{ background: rgba(46, 160, 67, 0.15); color: var(--green); border: 1px solid rgba(46, 160, 67, 0.4); border-radius: 20px; padding: 4px 12px; font-size: 12px; font-weight: 600; display: inline-flex; align-items: center; gap: 6px; }}\n  .badge .dot {{ width: 8px; height: 8px; background: var(--green); border-radius: 50%; box-shadow: 0 0 8px var(--green); }}\n  .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }}\n  .stat-card {{ background: var(--card); border: 1px solid var(--border); border-radius: 10px; padding: 18px; }}\n  .stat-label {{ font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--muted); margin-bottom: 6px; }}\n  .stat-value {{ font-size: 26px; font-weight: 700; color: var(--text); }}\n  .section {{ background: var(--card); border: 1px solid var(--border); border-radius: 10px; padding: 20px; margin-bottom: 24px; }}\n  .section-header {{ display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }}\n  h2 {{ font-size: 16px; font-weight: 600; color: var(--text); }}\n  table {{ width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }}\n  th {{ color: var(--muted); font-size: 12px; font-weight: 600; text-transform: uppercase; padding: 10px 12px; border-bottom: 1px solid var(--border); }}\n  td {{ padding: 12px; border-bottom: 1px solid rgba(48, 54, 61, 0.5); }}\n  tr:last-child td {{ border-bottom: none; }}\n  .peer-pill {{ display: inline-block; background: rgba(88, 166, 255, 0.15); color: var(--accent); border: 1px solid rgba(88, 166, 255, 0.3); border-radius: 12px; padding: 2px 10px; font-size: 12px; margin-right: 6px; }}\n  .btn {{ background: #21262d; color: var(--text); border: 1px solid var(--border); border-radius: 6px; padding: 6px 12px; font-size: 12px; font-weight: 500; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }}\n  .btn:hover {{ background: #30363d; border-color: #8b949e; }}\n  .empty-state {{ color: var(--muted); font-style: italic; padding: 20px 0; text-align: center; }}\n</style>\n</head>\n<body>\n<div class="container">\n  <div class="header">\n    <div class="title-group">\n      <h1>PlaceTogether 3.0</h1>\n      <span class="badge"><span class="dot"></span> ONLINE</span>\n    </div>\n    <div style="font-size: 13px; color: var(--muted);">Password: <strong>{('Enabled' if state.auth_secret else 'None')}</strong></div>\n  </div>\n\n  <div class="stats-grid">\n    <div class="stat-card">\n      <div class="stat-label">Active Rooms</div>\n      <div class="stat-value">{len(rooms_list)}</div>\n    </div>\n    <div class="stat-card">\n      <div class="stat-label">Synchronized Objects</div>\n      <div class="stat-value">{total_objs:,}</div>\n    </div>\n    <div class="stat-card">\n      <div class="stat-label">Connected Guests</div>\n      <div class="stat-value">{len(guests_list)}</div>\n    </div>\n    <div class="stat-card">\n      <div class="stat-label">Server Uptime</div>\n      <div class="stat-value">{uptime_str}</div>\n    </div>\n  </div>\n\n  <div class="section">\n    <div class="section-header">\n      <h2>Collaborative Rooms</h2>\n    </div>\n    {(f'<table>\n      <thead>\n        <tr>\n          <th>Room Name</th>\n          <th>Room ID</th>\n          <th>Revision</th>\n          <th>Objects</th>\n          <th>Active Peers</th>\n          <th>Export</th>\n        </tr>\n      </thead>\n      <tbody>\n        {''.join((f'<tr>\n          <td><strong>{r['name']}</strong><br><span style="color:var(--muted);font-size:12px">Host: {r['owner']}</span></td>\n          <td><code>{r['id']}</code></td>\n          <td><span style="color:var(--green)">rev {r['revision']}</span></td>\n          <td>{r['objects']:,}</td>\n          <td>{(''.join((f'<span class="peer-pill">{p}</span>' for p in r['peers'])) if r['peers'] else '<span style="color:var(--muted)">Idle</span>')}</td>\n          <td><a class="btn" href="/api/rooms/{r['id']}/export" download>📥 Download JSON</a></td>\n        </tr>' for r in rooms_list))}\n      </tbody>\n    </table>' if rooms_list else '<div class="empty-state">No active rooms yet. Click "Start Hosting Current Place" in the Roblox Studio plugin to create a room.</div>')}\n  </div>\n\n  <div class="section">\n    <div class="section-header">\n      <h2>Recent Guests & Peers</h2>\n    </div>\n    {(f'<table>\n      <thead>\n        <tr>\n          <th>Name</th>\n          <th>Token</th>\n          <th>Status</th>\n        </tr>\n      </thead>\n      <tbody>\n        {''.join((f'<tr>\n          <td><strong>{g['name']}</strong></td>\n          <td><code>{g['token']}</code></td>\n          <td>{('<span class="badge" style="padding:2px 8px;font-size:11px"><span class="dot"></span> Online</span>' if g['active'] else '<span style="color:var(--muted);font-size:12px">Idle</span>')}</td>\n        </tr>' for g in guests_list))}\n      </tbody>\n    </table>' if guests_list else '<div class="empty-state">No guests registered. Connect via the Roblox Studio PlaceTogether plugin.</div>')}\n  </div>\n</div>\n<script>\n  setTimeout(() => location.reload(), 4000);\n</script>\n</body>\n</html>'
            content = html.encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(content)))
            self.end_headers()
            self.wfile.write(content)

        def do_GET(self):
            path = self.path.split('?')[0]
            query_string = self.path.split('?')[1] if '?' in self.path else ''
            query_params = {}
            if query_string:
                for pair in query_string.split('&'):
                    if '=' in pair:
                        k, v = pair.split('=', 1)
                        query_params[k] = v
            token = self.get_token()
            if path == '/api/status' or path == '/':
                accept = self.headers.get('Accept', '')
                if path == '/' and 'text/html' in accept:
                    self.send_dashboard_html()
                    return
                if not self.secret_ok():
                    self.send_json(401, {'error': 'Неверный пароль сервера'})
                    return
                with state.lock:
                    self.send_json(200, {'server': 'PlaceTogether-UltraFast', 'version': '6.1.0', 'protocol': 5, 'status': 'online', 'uptime': int(time.time() - state.server_start_time), 'rooms_count': len(state.rooms), 'active_guests': len(state.guests), 'last_saved': state.last_disk_save_time, 'auth_required': bool(state.auth_secret)})
                return
            if not self.require_secret():
                return
            if path == '/api/rooms':
                if not self.require_guest(token):
                    return
                with state.lock:
                    now = time.time()
                    res = []
                    for r_id, r in state.rooms.items():
                        active_peers = [p.get('name', 'Peer') for p in r.get('presence', {}).values() if now - p.get('time', 0) < 15]
                        active_testers = [p.get('name', 'Peer') for p in r.get('presence', {}).values() if p.get('teamTest', {}).get('active') and now - p.get('time', 0) < 15]
                        res.append({'id': r_id, 'name': r['name'], 'closed': r.get('closed', False), 'persistent': r.get('persistent', True), 'members': list(r.get('members', [])), 'activePeers': active_peers, 'activeTesters': active_testers, 'teamTestActive': len(active_testers) > 0, 'revision': r.get('revision', 1), 'objectsCount': len(r.get('objects', {})), 'lastSaved': r.get('last_saved', 0), 'updatedAt': r.get('updated_at', 0)})
                    res.sort(key=lambda x: x.get('updatedAt', 0), reverse=True)
                    self.send_json(200, res)
                return
            if path.startswith('/api/rooms/') and path.endswith('/sync'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Комната не найдена'})
                        return
                    r = state.rooms[room_id]
                    try:
                        since_rev = int(query_params.get('since', 0))
                    except ValueError:
                        since_rev = 0
                    self.remember_client_revision(r, token, since_rev)
                    if since_rev > 0 and since_rev == r['revision']:
                        self.send_json(200, {'revision': r['revision'], 'unchanged': True, 'objects': {}, 'lastSaved': r.get('last_saved', 0), 'objectsCount': len(r['objects'])})
                        return
                    if 0 < since_rev < r['revision']:
                        deltas = self.compute_deltas_since(r, since_rev)
                        self.send_json(200, {'revision': r['revision'], 'unchanged': len(deltas) == 0, 'objects': deltas, 'delta': True, 'lastSaved': r.get('last_saved', 0), 'objectsCount': len(r['objects'])})
                        return
                    self.send_json(200, {'revision': r['revision'], 'objects': r['objects'], 'owner': r['owner'], 'lastSaved': r.get('last_saved', 0), 'objectsCount': len(r['objects'])})
                return
            if path.startswith('/api/rooms/') and path.endswith('/state'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Комната не найдена'})
                        return
                    r = state.rooms[room_id]
                    now = time.time()
                    user_name = state.guests.get(token, {}).get('name', '')
                    active_testers = [p.get('name', 'Peer') for p in r.get('presence', {}).values() if p.get('teamTest', {}).get('active') and now - p.get('time', 0) < 15]
                    is_owner = r['owner'] == token
                    self.send_json(200, {'id': room_id, 'name': r['name'], 'isOwner': is_owner, 'closed': r.get('closed', False), 'persistent': r.get('persistent', True), 'revision': r.get('revision', 1), 'objectsCount': len(r.get('objects', {})), 'lastSaved': r.get('last_saved', 0), 'activeTesters': active_testers, 'teamTestActive': len(active_testers) > 0})
                return
            if path.startswith('/api/rooms/') and path.endswith('/backups'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Комната не найдена'})
                        return
                backups = state.list_room_backups(room_id)
                self.send_json(200, backups)
                return
            if path == '/api/invitations':
                if not self.require_guest(token):
                    return
                with state.lock:
                    if token in state.guests:
                        state.guests[token]['last_seen'] = time.time()
                    user_name = state.guests.get(token, {}).get('name', '')
                    pending = []
                    for inv in state.invitations:
                        if inv.get('nick', '').lower() == user_name.lower() and inv.get('state') == 'pending':
                            inv['delivered'] = True
                            pending.append(inv)
                    self.send_json(200, pending)
                return
            if path == '/api/invitations/outbox':
                if not self.require_guest(token):
                    return
                with state.lock:
                    user_name = state.guests.get(token, {}).get('name', '')
                    now = time.time()
                    my_invites = []
                    for inv in state.invitations:
                        if inv.get('from') == user_name:
                            target_nick = inv.get('nick', '').lower()
                            inv['recipientOnline'] = any((g.get('name', '').lower() == target_nick and now - g.get('last_seen', 0) < 30 for g in state.guests.values()))
                            my_invites.append(inv)
                    self.send_json(200, my_invites)
                return
            if path.startswith('/api/rooms/') and path.endswith('/export'):
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Room not found'})
                        return
                    r = state.rooms[room_id]
                    serialized = state.serialize_room(r)
                content = json.dumps(serialized, indent=2, ensure_ascii=False).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Disposition', f'attachment; filename="room_{room_id}_rev{r.get('revision', 1)}.json"')
                self.send_header('Content-Length', str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return
            if path.startswith('/api/rooms/') and path.endswith('/chat'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Room not found'})
                        return
                    r = state.rooms[room_id]
                    since_id = query_params.get('since', '')
                    chat_list = r.get('chat', [])
                    if since_id:
                        idx = -1
                        for i, m in enumerate(chat_list):
                            if m.get('id') == since_id:
                                idx = i
                                break
                        if idx >= 0:
                            chat_list = chat_list[idx + 1:]
                    self.send_json(200, {'messages': chat_list, 'total': len(r.get('chat', []))})
                return
            self.send_json(404, {'error': 'Endpoint not found'})

        def do_POST(self):
            path = self.path.split('?')[0]
            try:
                data = self.read_body()
            except state.BodyTooLarge:
                self.close_connection = True
                self.send_json(413, {'error': 'Слишком большое тело запроса'})
                return
            except Exception as e:
                self.close_connection = True
                self.send_json(400, {'error': f'Invalid JSON body: {e}'})
                return
            token = self.get_token()
            if not self.require_secret():
                return
            if path == '/api/guest':
                name = str(data.get('name', 'Guest')).strip() or 'Guest'
                device_key = str(data.get('deviceKey', '')).strip()
                if device_key and (len(device_key) > 128 or not device_key.isprintable()):
                    self.send_json(400, {'error': 'Invalid deviceKey'})
                    return
                with state.lock:
                    guest_token = device_key if device_key else token or f'token_{int(time.time() * 1000)}'
                    now = time.time()
                    final_name = name
                    rename_explicit = bool(data.get('rename', False))
                    if not rename_explicit:
                        existing_active_names = {g.get('name', '').lower(): g.get('name', '') for t, g in state.guests.items() if t != guest_token and now - g.get('last_seen', 0) < 30}
                        if final_name.lower() in existing_active_names:
                            idx = 2
                            while f'{name}{idx}'.lower() in existing_active_names:
                                idx += 1
                            final_name = f'{name}{idx}'
                    old_name = state.guests.get(guest_token, {}).get('name')
                    state.guests[guest_token] = {'name': final_name, 'deviceKey': device_key, 'last_seen': now}
                    if old_name and old_name != final_name:
                        for r in state.rooms.values():
                            if old_name in r.get('members', set()):
                                r['members'].discard(old_name)
                                r['members'].add(final_name)
                    state.mark_dirty()
                    print(f'[AUTH] User connected: {final_name} ({guest_token[:8]}...)')
                    self.send_json(200, {'token': guest_token, 'name': final_name})
                return
            if path == '/api/rooms':
                if not self.require_guest(token):
                    return
                name = str(data.get('name', 'Studio Project')).strip() or 'Studio Project'
                with state.lock:
                    user_name = state.guests.get(token, {}).get('name', 'User')
                    room_id = uuid.uuid4().hex[:12]
                    now = time.time()
                    state.rooms[room_id] = {'name': name, 'mode': 'copy' if data.get('mode') == 'copy' else 'live', 'ready': False, 'load': {}, 'owner': token, 'owner_name': user_name, 'revision': 1, 'objects': {}, 'tombstones': {}, 'presence': {}, 'chat': [], 'persistent': True, 'closed': False, 'members': {user_name}, 'last_saved': now, 'updated_at': now}
                    state.mark_dirty(room_id)
                    print(f"[ROOM] Created room '{name}' (id={room_id}) by {user_name}")
                    self.send_json(200, {'id': room_id, 'name': name})
                state.save_data(state.data_filepath, force=True)
                return
            if path.startswith('/api/rooms/') and path.endswith('/join'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Комната не найдена'})
                        return
                    r = state.rooms[room_id]
                    user_name = state.guests.get(token, {}).get('name', 'User')
                    r.setdefault('members', set()).add(user_name)
                    state.mark_dirty(room_id)
                    print(f"[ROOM] {user_name} joined room '{r['name']}' (id={room_id})")
                    self.send_json(200, {'id': room_id, 'name': r['name'], 'revision': r['revision'], 'objectsCount': len(r['objects'])})
                return
            if path.startswith('/api/rooms/') and path.endswith('/sync'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Комната не найдена'})
                        return
                    r = state.rooms[room_id]
                    peer = state.locking_peer(r, token)
                    if peer is not None:
                        self.send_json(423, {'loading': True, 'error': 'Peer is loading Terrain/map', 'peerTask': peer.get('task'), 'revision': r['revision']})
                        return
                    changes = data.get('changes', [])
                    if not isinstance(changes, list):
                        self.send_json(400, {'error': 'changes must be a list'})
                        return
                    if len(changes) > 20000:
                        self.send_json(413, {'error': 'Слишком много изменений за один запрос'})
                        return
                    try:
                        since_rev = int(data.get('since', 0))
                    except (TypeError, ValueError):
                        since_rev = 0
                    self.remember_client_revision(r, token, since_rev)
                    remote_deltas = {}
                    if since_rev > 0 and since_rev < r['revision']:
                        remote_deltas = self.compute_deltas_since(r, since_rev)
                    applied_count = 0
                    new_rev = r['revision'] + 1
                    tombstones = r.setdefault('tombstones', {})
                    for ch in changes:
                        if not isinstance(ch, dict):
                            continue
                        obj_id = ch.get('id')
                        if not isinstance(obj_id, str) or not obj_id or len(obj_id) > 512:
                            continue
                        if ch.get('deleted') or ch.get('value') is None:
                            if obj_id in r['objects'] or obj_id not in tombstones:
                                r['objects'].pop(obj_id, None)
                                tombstones[obj_id] = {'version': new_rev, 'value': None}
                                applied_count += 1
                        else:
                            val = ch.get('value')
                            existing = r['objects'].get(obj_id)
                            if isinstance(existing, dict) and obj_id not in tombstones and (existing.get('value') == val):
                                continue
                            rec = {'version': new_rev, 'value': val}
                            r['objects'][obj_id] = rec
                            tombstones.pop(obj_id, None)
                            applied_count += 1
                    if applied_count > 0:
                        r['revision'] = new_rev
                        r['sizeBytes'] = sum((state.object_size(rec.get('value')) for rec in r['objects'].values()))
                        state.mark_dirty(room_id)
                    self.send_json(200, {'revision': r['revision'], 'applied': True, 'remoteChanges': remote_deltas, 'lastSaved': r.get('last_saved', 0), 'objectsCount': len(r['objects'])})
                return
            if path.startswith('/api/rooms/') and path.endswith('/presence'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Room not found'})
                        return
                    r = state.rooms[room_id]
                    if token in state.guests:
                        state.guests[token]['last_seen'] = time.time()
                    user_info = state.guests.get(token, {})
                    user_name = user_info.get('name', 'Peer')
                    if data.get('leave'):
                        r['presence'].pop(token, None)
                    else:
                        r['presence'][token] = {'id': token, 'name': user_name, 'position': data.get('position', [0, 10, 0]), 'look': data.get('look', [0, 0, -1]), 'selected': data.get('selected', []), 'transforms': data.get('transforms', {}), 'teamTest': data.get('teamTest', None), 'activeScript': data.get('activeScript', None), 'ping': dict(data['ping'], time=time.time()) if isinstance(data.get('ping'), dict) else None, 'hue': state.stable_hue(token), 'time': time.time()}
                    now = time.time()
                    active_peers = []
                    for p_id, p in list(r['presence'].items()):
                        if now - p.get('time', 0) < 12:
                            if p_id != token:
                                item = copy.deepcopy(p)
                                if item.get('ping'):
                                    item['ping']['age'] = max(0, now - item['ping']['time'])
                                active_peers.append(item)
                        else:
                            del r['presence'][p_id]
                    self.send_json(200, active_peers)
                return
            if path == '/api/invitations':
                if not self.require_guest(token):
                    return
                target_nick = str(data.get('nick', '')).strip()
                room_id = str(data.get('room', '')).strip()
                with state.lock:
                    inv_id = str(state.next_invite_id)
                    state.next_invite_id += 1
                    sender_name = state.guests.get(token, {}).get('name', 'Host')
                    now = time.time()
                    is_online = any((g.get('name', '').lower() == target_nick.lower() and now - g.get('last_seen', 0) < 30 for g in state.guests.values()))
                    inv = {'id': inv_id, 'from': sender_name, 'nick': target_nick, 'room': room_id, 'place': state.rooms.get(room_id, {}).get('name', 'Studio Project'), 'state': 'pending', 'recipientOnline': is_online, 'delivered': False, 'created_at': now}
                    state.invitations.append(inv)
                    print(f'[INVITE] {sender_name} invited {target_nick} to room {room_id}')
                    self.send_json(200, inv)
                return
            if path.startswith('/api/invitations/') and path.endswith('/respond'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                inv_id = parts[3]
                decision = data.get('decision', 'accept')
                with state.lock:
                    for inv in state.invitations:
                        if inv.get('id') == inv_id:
                            inv['state'] = 'accepted' if decision == 'accept' else 'declined'
                            room_id = inv.get('room')
                            r = state.rooms.get(room_id, {})
                            user_name = state.guests.get(token, {}).get('name', 'User')
                            if decision == 'accept' and r:
                                r.setdefault('members', set()).add(user_name)
                                state.mark_dirty(room_id)
                            print(f'[INVITE] {user_name} {inv['state']} invite #{inv_id} for room {room_id}')
                            self.send_json(200, {'decision': decision, 'room': {'id': room_id, 'name': r.get('name', 'Studio Project')}})
                            return
                    self.send_json(404, {'error': 'Приглашение не найдено'})
                return
            if path.startswith('/api/rooms/') and path.endswith('/save'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                label = str(data.get('label', 'manual')).strip() or 'manual'
                create_snap = data.get('snapshot', True)
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Room not found'})
                        return
                    r = state.rooms[room_id]
                    if data.get('name'):
                        r['name'] = str(data['name']).strip() or r['name']
                    r['persistent'] = True
                    state.mark_dirty(room_id)
                    rev = r['revision']
                    obj_count = len(r['objects'])
                saved_ok = state.save_data(state.data_filepath, force=True)
                backup_info = state.create_room_backup(room_id, label=label) if create_snap else None
                print(f'[SAVE] Room {room_id} saved (rev={rev}, objects={obj_count}, snapshot={bool(backup_info)})')
                self.send_json(200, {'saved': saved_ok, 'persistent': True, 'revision': rev, 'objectsCount': obj_count, 'lastSaved': time.time(), 'backup': {'id': backup_info['backup_id'], 'date': backup_info['date']} if backup_info else None})
                return
            if path.startswith('/api/rooms/') and path.endswith('/restore'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                backup_id = data.get('backupId')
                with state.lock:
                    r = state.rooms.get(room_id)
                    if r is None:
                        self.send_json(404, {'error': 'Комната не найдена'})
                        return
                    user_name = state.guests.get(token, {}).get('name', '')
                    is_owner = r.get('owner') == token
                if not is_owner:
                    self.send_json(403, {'error': 'Восстановить комнату может только её владелец'})
                    return
                result, err = state.restore_room_backup(room_id, backup_id)
                if err:
                    self.send_json(400, {'error': err})
                else:
                    self.send_json(200, result)
                return
            if path.startswith('/api/rooms/') and path.endswith('/chat'):
                if not self.require_guest(token):
                    return
                parts = path.split('/')
                room_id = parts[3]
                with state.lock:
                    if room_id not in state.rooms:
                        self.send_json(404, {'error': 'Комната не найдена'})
                        return
                    r = state.rooms[room_id]
                    raw_text = str(data.get('text', '')).strip()
                    if not raw_text:
                        self.send_json(400, {'error': 'Message text cannot be empty'})
                        return
                    user_name = state.guests.get(token, {}).get('name', 'User')
                    msg = {'id': uuid.uuid4().hex, 'from': user_name, 'text': raw_text[:500], 'time': time.time(), 'hue': state.stable_hue(token)}
                    r.setdefault('chat', []).append(msg)
                    if len(r['chat']) > 200:
                        r['chat'] = r['chat'][-200:]
                    state.mark_dirty(room_id)
                    self.send_json(200, {'ok': True, 'message': msg})
                return
            self.send_json(404, {'error': 'Endpoint not found'})
    state.BaseRequestHandler = LegacyHandler

    def setup_shutdown_hooks():

        def on_exit(*args):
            if state.dirty_flag:
                print('\n[INFO] Flushing unsaved changes to disk before exit...')
                state.save_data(state.data_filepath, force=True)
        atexit.register(on_exit)
        for sig_name in ('SIGINT', 'SIGTERM', 'SIGBREAK'):
            sig = getattr(signal, sig_name, None)
            if sig is not None:
                try:
                    signal.signal(sig, lambda s, f: sys.exit(0))
                except Exception:
                    pass
    state.setup_shutdown_hooks = setup_shutdown_hooks
    state.HEAVY_OBJECTS = 2500
    state.HEAVY_BYTES = 8 * 1024 * 1024
    state.LOAD_EXPIRE_SECONDS = 180
