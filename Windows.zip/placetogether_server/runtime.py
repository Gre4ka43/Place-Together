"""Explicit server-state component; instantiated by application.create_application."""
import uuid
import copy
import urllib.parse
import json
import os
import socket
import subprocess
import sys
import os
import json
import time
import hmac
import gzip
import shutil
import signal
import atexit
import hashlib
import difflib
import argparse
import threading
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

def install(state):

    def auto_saver(stop):
        last_auto_backup_rev = {r_id: r['revision'] for r_id, r in state.rooms.items()}
        last_backup_check = time.time()
        last_cleanup = time.time()
        while not stop.wait(1.0):
            now = time.time()
            should_save = False
            with state.lock:
                if state.dirty_flag:
                    if now - state.last_change_time >= 2.0 or now - state.last_disk_save_time >= 12.0:
                        should_save = True
            if should_save:
                state.save_data(state.data_filepath)
            if now - last_cleanup >= 60.0:
                last_cleanup = now
                state.cleanup_stale()
            if now - last_backup_check >= 300.0:
                last_backup_check = now
                with state.lock:
                    room_ids = list(state.rooms.keys())
                for r_id in room_ids:
                    with state.lock:
                        r = state.rooms.get(r_id)
                        if not r:
                            continue
                        cur_rev = r['revision']
                        obj_cnt = len(r.get('objects', {}))
                    if obj_cnt > 0 and last_auto_backup_rev.get(r_id, 0) != cur_rev:
                        state.create_room_backup(r_id, label='autosave')
                        last_auto_backup_rev[r_id] = cur_rev

    def start_autosaver(stop):
        thread = threading.Thread(target=auto_saver, args=(stop,), daemon=True)
        thread.start()
        return thread
    state.start_autosaver = start_autosaver

    def main():
        parser = argparse.ArgumentParser(description='PlaceTogether Ultra-Fast Server Studio 6.1')
        parser.add_argument('--port', type=int, default=state.DEFAULT_PORT, help=f'Port to bind (default: {state.DEFAULT_PORT})')
        parser.add_argument('--data', type=str, default=state.DATA_FILE, help='Path to data JSON file')
        parser.add_argument('--secret', type=str, default=os.environ.get('PT_SECRET', ''), help='Shared password. When set, clients must send X-PT-Secret (env: PT_SECRET)')
        parser.add_argument('--cors-origin', type=str, default=os.environ.get('PT_CORS_ORIGIN', ''), help='Allow browser cross-origin access from this exact origin (default: disabled)')
        args = parser.parse_args()
        state.auth_secret = str(args.secret or '')
        state.cors_origin = str(args.cors_origin or '')
        state.data_filepath = os.path.abspath(args.data)
        state.backups_dir = state.get_backups_dir(state.data_filepath)
        state.load_data(state.data_filepath)
        state.setup_shutdown_hooks()

        state.start_autosaver(threading.Event())
        server_address = ('0.0.0.0', args.port)
        httpd = state.ConcurrentServer(server_address, state.StudioRequestHandler)
        print('============================================================')
        print(f'  PlaceTogether Ultra-Fast Server Studio 6.1 running on port {args.port}')
        print(f'  Data File : {state.data_filepath}')
        print(f'  Backups   : {state.backups_dir}')
        password_status = 'enabled (X-PT-Secret)' if state.auth_secret else 'disabled (open on the network!)'
        print(f'  Password  : {password_status}')
        print('  Features  : Lossless Delta Sync | Live 60FPS Drag | Auto-Save')
        print('============================================================')
        state.print_connection_help(args.port, bool(state.auth_secret))
        try:
            httpd.serve_forever()
        except (KeyboardInterrupt, SystemExit):
            print('\n[INFO] Shutting down server and saving data...')
            state.save_data(state.data_filepath, force=True)
            sys.exit(0)
    state.main = main
