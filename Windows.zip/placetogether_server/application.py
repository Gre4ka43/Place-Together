"""Application composition and process lifecycle."""
from . import storage, http, protocol, runtime

class ServerState:
    """One isolated server instance; no shared room database between instances."""

def create_application():
    state = ServerState()
    for component in (storage, http, protocol, runtime):
        component.install(state)
    return state

def run():
    create_application().main()
