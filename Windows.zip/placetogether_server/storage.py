"""Explicit server-state component; instantiated by application.create_application."""
import uuid
import copy
import urllib.parse
import json
import os
import socket
import subprocess
import sys
import os
import json
import time
import hmac
import gzip
import shutil
import signal
import atexit
import hashlib
import difflib
import argparse
import threading
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn

def install(state):

    def discover_ipv4():
        """Return (adapter name, IPv4) without sending traffic to an external host."""
        found = []
        if os.name == 'nt':
            script = "[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)\nGet-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |\nWhere-Object { $_.IPAddress -notmatch '^127\\.|^169\\.254\\.' -and $_.AddressState -eq 'Preferred' } |\nSelect-Object InterfaceAlias,IPAddress | ConvertTo-Json -Compress"
            try:
                result = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=5, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0), check=False)
                if result.returncode == 0 and result.stdout.strip():
                    records = json.loads(result.stdout)
                    if isinstance(records, dict):
                        records = [records]
                    for record in records or []:
                        address = str(record.get('IPAddress', ''))
                        if address and (not address.startswith(('127.', '169.254.'))):
                            found.append((str(record.get('InterfaceAlias', 'Network')), address))
            except (OSError, ValueError, subprocess.TimeoutExpired):
                pass
        if not found:
            try:
                for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
                    address = item[4][0]
                    if not address.startswith(('127.', '169.254.')):
                        found.append(('Network', address))
            except OSError:
                pass
        unique = {address: name for name, address in found}
        return sorted(((name, address) for address, name in unique.items()), key=lambda x: (x[0].lower(), x[1]))
    state.discover_ipv4 = discover_ipv4

    def print_connection_help(port, password_enabled=False, adapters=None):
        if adapters is None:
            adapters = state.discover_ipv4()
        print()
        print('============================================================')
        print('  ЧТО ВВОДИТЬ В ПЛАГИНЕ ROBLOX STUDIO -> SETTINGS')
        print('============================================================')
        print('  ТЫ, НА ЭТОМ КОМПЬЮТЕРЕ:')
        print('    IP / Host : localhost')
        print(f'    Port      : {port}')
        print()
        print('  ДРУГ: вводит ТВОЙ адрес из подходящей сети:')
        for name, address in adapters:
            label = 'VPN' if any((word in name.lower() for word in ('radmin', 'hamachi', 'zerotier', 'tailscale', 'wireguard', 'vpn'))) else 'LAN / Network'
            print(f'    [{label}] {name}')
            print(f'      IP / Host : {address}')
            print(f'      Port      : {port}')
        if not adapters:
            print('    Не удалось автоматически определить LAN/VPN IP.')
            print('    Посмотри свой адрес в Radmin VPN или командой ipconfig.')
        print()
        print('  Radmin/Hamachi/ZeroTier: оба участника в одной VPN-сети.')
        print('  LAN / Wi-Fi: оба участника в одной локальной сети.')
        print('  Друг не должен вводить localhost или 0.0.0.0.')
        print('  Через интернет без общей VPN нужен туннель или проброс порта.')
        print('  Полный https:// адрес туннеля вставляется в IP / Host.')
        print('  Password  : ' + ('введите заданный пароль сервера' if password_enabled else 'оставьте поле пустым'))
        print()
        print('  ДАЛЬШЕ: ты -> Host New Session -> дождаться загрузки карты.')
        print('  Передай другу код комнаты -> друг нажимает Join by Room Code.')
        print(f'  Веб-панель на твоём ПК: http://127.0.0.1:{port}')
        print('  Оставь это окно открытым. Ctrl+C останавливает сервер.')
        print('============================================================')
        print(flush=True)
    state.print_connection_help = print_connection_help
    state.DEFAULT_PORT = 8787
    state.DATA_FILE = 'data.json'
    state.MAX_BACKUPS_PER_ROOM = 25
    state.MAX_TOMBSTONES_PER_ROOM = 5000
    state.MAX_BODY_BYTES = 64 * 1024 * 1024
    state.GUEST_TTL_SECONDS = 30 * 24 * 3600
    state.INVITE_TTL_SECONDS = 24 * 3600
    state.CLIENT_REV_TTL_SECONDS = 60
    state.lock = threading.RLock()
    state.rooms = {}
    state.guests = {}
    state.invitations = []
    state.next_invite_id = 1
    state.auth_secret = ''
    state.cors_origin = ''
    state.data_filepath = state.DATA_FILE
    state.backups_dir = 'backups'
    state.dirty_flag = False
    state.last_change_time = 0.0
    state.last_disk_save_time = 0.0
    state.server_start_time = time.time()
    state.save_lock = threading.Lock()

    def get_backups_dir(base_data_file):
        base_dir = os.path.dirname(os.path.abspath(base_data_file))
        bdir = os.path.join(base_dir, 'backups')
        os.makedirs(bdir, exist_ok=True)
        return bdir
    state.get_backups_dir = get_backups_dir

    def mark_dirty(room_id=None):
        with state.lock:
            state.dirty_flag = True
            state.last_change_time = time.time()
            if room_id and room_id in state.rooms:
                state.rooms[room_id]['updated_at'] = state.last_change_time
    state.mark_dirty = mark_dirty

    def stable_hue(token):
        """Deterministic peer colour. builtin hash() is salted per process, so the
    same peer changed colour after every server restart."""
        digest = hashlib.sha1(str(token or '').encode('utf-8')).hexdigest()
        return int(digest[:8], 16) % 100 / 100.0
    state.stable_hue = stable_hue

    def cleanup_stale():
        """Drop expired guests, invitations and presence entries.

    Guests and invitations used to grow without bound (memory + data.json).
    """
        now = time.time()
        changed = False
        with state.lock:
            owners = {r.get('owner') for r in state.rooms.values()}
            stale_guests = [tok for tok, g in state.guests.items() if now - g.get('last_seen', 0) > state.GUEST_TTL_SECONDS and tok not in owners]
            for tok in stale_guests:
                state.guests.pop(tok, None)
                changed = True
            kept = []
            for inv in state.invitations:
                age = now - inv.get('created_at', now)
                finished = inv.get('state') in ('accepted', 'declined')
                if age > state.INVITE_TTL_SECONDS or (finished and age > 600):
                    changed = True
                    continue
                kept.append(inv)
            if len(kept) != len(state.invitations):
                state.invitations[:] = kept
            for r in state.rooms.values():
                presence = r.get('presence') or {}
                for p_id in [pid for pid, p in presence.items() if now - p.get('time', 0) > 120]:
                    presence.pop(p_id, None)
                clients = r.get('clients') or {}
                for key in [k for k, v in clients.items() if now - v.get('time', 0) > state.CLIENT_REV_TTL_SECONDS]:
                    clients.pop(key, None)
            if changed:
                state.dirty_flag = True
        return changed
    state.cleanup_stale = cleanup_stale

    def serialize_room(r):
        return {'name': r.get('name', 'Studio Project'), 'owner': r.get('owner', ''), 'mode': r.get('mode', 'live'), 'ready': r.get('ready', True), 'restoreEpoch': r.get('restoreEpoch', 0), 'owner_name': r.get('owner_name', ''), 'revision': r.get('revision', 1), 'objects': r.get('objects', {}), 'tombstones': r.get('tombstones', {}), 'persistent': r.get('persistent', True), 'closed': r.get('closed', False), 'members': list(r.get('members', [])), 'chat': list(r.get('chat', []))[-100:], 'last_saved': r.get('last_saved', time.time()), 'updated_at': r.get('updated_at', time.time())}
    state.serialize_room = serialize_room

    def prune_tombstones(r):
        """Drop tombstones no connected peer can still need.

    Old behaviour kept an arbitrary half of the list, which silently resurrected
    deleted objects for peers that were further behind. Now a tombstone is only
    dropped once *every* recently active client already knows about it, i.e. its
    version is <= the smallest `since` revision any peer is polling with.
    """
        if r.get('mode') == 'copy':
            return
        tombstones = r.get('tombstones') or {}
        if len(tombstones) <= state.MAX_TOMBSTONES_PER_ROOM:
            return
        now = time.time()
        since_values = [info.get('since', 0) for info in r.get('clients', {}).values() if now - info.get('time', 0) <= state.CLIENT_REV_TTL_SECONDS]
        if not since_values:
            return
        min_safe_rev = min(since_values)
        r['tombstones'] = {obj_id: tomb for obj_id, tomb in tombstones.items() if tomb.get('version', 0) > min_safe_rev}
    state.prune_tombstones = prune_tombstones

    def analyze_diff_lines(base_lines, mod_lines):
        n = len(base_lines)
        inserts = {i: [] for i in range(n + 1)}
        state = ['deleted'] * n
        sm = difflib.SequenceMatcher(None, base_lines, mod_lines)
        for tag, b1, b2, m1, m2 in sm.get_opcodes():
            if tag == 'equal':
                for i in range(b1, b2):
                    state[i] = 'equal'
            elif tag in ('insert', 'replace'):
                inserts[b1].extend(mod_lines[m1:m2])
        return (inserts, state)
    state.analyze_diff_lines = analyze_diff_lines

    def merge_3way_text(base_str, text_a, text_b):
        if text_a == text_b:
            return text_a
        if not text_a:
            return text_b
        if not text_b:
            return text_a
        lines_a = text_a.replace('\r\n', '\n').replace('\r', '\n').split('\n')
        lines_b = text_b.replace('\r\n', '\n').replace('\r', '\n').split('\n')
        if not base_str:
            matcher = difflib.SequenceMatcher(None, lines_a, lines_b)
            res = []
            for tag, i1, i2, j1, j2 in matcher.get_opcodes():
                if tag == 'equal':
                    res.extend(lines_a[i1:i2])
                elif tag == 'replace':
                    res.extend(lines_a[i1:i2])
                    res.extend(lines_b[j1:j2])
                elif tag == 'delete':
                    res.extend(lines_a[i1:i2])
                elif tag == 'insert':
                    res.extend(lines_b[j1:j2])
            return '\n'.join(res)
        lines_base = base_str.replace('\r\n', '\n').replace('\r', '\n').split('\n')
        if lines_a == lines_base:
            return text_b
        if lines_b == lines_base:
            return text_a
        ins_a, st_a = state.analyze_diff_lines(lines_base, lines_a)
        ins_b, st_b = state.analyze_diff_lines(lines_base, lines_b)
        n = len(lines_base)
        res = []
        for i in range(n + 1):
            in_a = ins_a[i]
            in_b = ins_b[i]
            if in_a and (not in_b):
                res.extend(in_a)
            elif in_b and (not in_a):
                res.extend(in_b)
            elif in_a and in_b:
                if in_a == in_b:
                    res.extend(in_a)
                else:
                    res.extend(in_a)
                    res.extend(in_b)
            if i < n:
                if st_a[i] == 'deleted' or st_b[i] == 'deleted':
                    pass
                else:
                    res.append(lines_base[i])
        return '\n'.join(res)
    state.merge_3way_text = merge_3way_text

    def save_data(filepath=None, force=False):
        if filepath is None:
            filepath = state.data_filepath
        with state.lock:
            if not state.dirty_flag and (not force):
                return False
            now = time.time()
            clean_rooms = {}
            for r_id, r in state.rooms.items():
                state.prune_tombstones(r)
                r['last_saved'] = now
                clean_rooms[r_id] = state.serialize_room(r)
            payload = {'version': '6.1.0', 'saved_at': now, 'rooms': clean_rooms, 'guests': dict(state.guests)}
            state.dirty_flag = False
            state.last_disk_save_time = now
            try:
                text = json.dumps(payload, ensure_ascii=False, separators=(',', ':'))
            except Exception as e:
                state.dirty_flag = True
                print(f'[ERROR] Failed to serialize data: {e}', file=sys.stderr)
                return False
        with state.save_lock:
            try:
                abs_path = os.path.abspath(filepath)
                os.makedirs(os.path.dirname(abs_path), exist_ok=True)
                temp_path = abs_path + '.tmp'
                bak_path = abs_path + '.bak'
                with open(temp_path, 'w', encoding='utf-8') as f:
                    f.write(text)
                    f.flush()
                    os.fsync(f.fileno())
                if os.path.exists(abs_path):
                    try:
                        shutil.copy2(abs_path, bak_path)
                    except Exception:
                        pass
                os.replace(temp_path, abs_path)
                return True
            except Exception as e:
                print(f'[ERROR] Failed to save data to {filepath}: {e}', file=sys.stderr)
                with state.lock:
                    state.dirty_flag = True
                return False
    state.save_data = save_data

    def create_room_backup(room_id, label='auto'):
        with state.lock:
            if room_id not in state.rooms:
                return None
            r = state.rooms[room_id]
            room_data = copy.deepcopy(state.serialize_room(r))
            rev = r['revision']
            obj_count = len(r.get('objects', {}))
        try:
            bdir = state.get_backups_dir(state.data_filepath)
            ts = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            safe_label = ''.join((c for c in label if c.isalnum() or c in ('-', '_')))[:24] or 'snap'
            filename = f'room_{room_id}_{ts}_rev{rev}_{safe_label}.json'
            full_path = os.path.join(bdir, filename)
            backup_payload = {'backup_id': filename, 'room_id': room_id, 'label': label, 'timestamp': time.time(), 'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'revision': rev, 'objects_count': obj_count, 'room': room_data}
            with open(full_path, 'w', encoding='utf-8') as f:
                json.dump(backup_payload, f, ensure_ascii=False, separators=(',', ':'))
            prefix = f'room_{room_id}_'
            existing = sorted([fn for fn in os.listdir(bdir) if fn.startswith(prefix) and fn.endswith('.json')])
            while len(existing) > state.MAX_BACKUPS_PER_ROOM:
                oldest = existing.pop(0)
                try:
                    os.remove(os.path.join(bdir, oldest))
                except Exception:
                    pass
            return backup_payload
        except Exception as e:
            print(f'[WARN] Failed to create room backup for {room_id}: {e}', file=sys.stderr)
            return None
    state.create_room_backup = create_room_backup

    def list_room_backups(room_id):
        bdir = state.get_backups_dir(state.data_filepath)
        prefix = f'room_{room_id}_'
        results = []
        try:
            files = sorted([fn for fn in os.listdir(bdir) if fn.startswith(prefix) and fn.endswith('.json')], reverse=True)
            for fn in files:
                fpath = os.path.join(bdir, fn)
                try:
                    with open(fpath, 'r', encoding='utf-8') as f:
                        meta = json.load(f)
                    results.append({'id': fn, 'label': meta.get('label', 'backup'), 'date': meta.get('date', fn), 'timestamp': meta.get('timestamp', 0), 'revision': meta.get('revision', 1), 'objectsCount': meta.get('objects_count', len(meta.get('room', {}).get('objects', {})))})
                except Exception:
                    continue
        except Exception:
            pass
        return results
    state.list_room_backups = list_room_backups

    def restore_room_backup(room_id, backup_id=None):
        bdir = state.get_backups_dir(state.data_filepath)
        if not backup_id:
            backups = state.list_room_backups(room_id)
            if not backups:
                return (None, 'Нет доступных резервных копий для этой комнаты')
            backup_id = backups[0]['id']
        backup_id = os.path.basename(backup_id)
        if not backup_id.startswith(f'room_{room_id}_'):
            return (None, 'Backup belongs to another room')
        fpath = os.path.join(bdir, backup_id)
        if not os.path.exists(fpath):
            return (None, 'Файл резервной копии не найден')
        try:
            with open(fpath, 'r', encoding='utf-8') as f:
                backup_payload = json.load(f)
            saved_room = backup_payload.get('room', {})
            saved_objects = saved_room.get('objects', {})
        except Exception as e:
            return (None, f'Ошибка чтения бэкапа: {e}')
        state.create_room_backup(room_id, label='pre_restore')
        with state.lock:
            if room_id not in state.rooms:
                return (None, 'Комната не найдена')
            r = state.rooms[room_id]
            new_rev = r['revision'] + 1
            r['revision'] = new_rev
            r['restoreEpoch'] = r.get('restoreEpoch', 0) + 1
            current_keys = set(r['objects'].keys())
            restored_keys = set(saved_objects.keys())
            removed_keys = current_keys - restored_keys
            tombstones = r.setdefault('tombstones', {})
            for rem_key in removed_keys:
                tombstones[rem_key] = {'version': new_rev, 'value': None}
            new_objects = {}
            for obj_id, rec in saved_objects.items():
                val = rec.get('value') if isinstance(rec, dict) and 'value' in rec else rec
                new_objects[obj_id] = {'version': new_rev, 'value': val}
                if obj_id in tombstones:
                    del tombstones[obj_id]
            r['objects'] = new_objects
            r['sizeBytes'] = sum((state.object_size(rec.get('value')) for rec in new_objects.values()))
            state.mark_dirty(room_id)
        state.save_data(state.data_filepath, force=True)
        print(f'[RESTORE] Room {room_id} restored from {backup_id} -> rev {new_rev} ({len(new_objects)} objects)')
        return ({'restored': True, 'backupId': backup_id, 'revision': new_rev, 'objectsCount': len(new_objects)}, None)
    state.restore_room_backup = restore_room_backup

    def load_data(filepath):
        abs_path = os.path.abspath(filepath)
        bak_path = abs_path + '.bak'
        target_to_load = None
        if os.path.exists(abs_path):
            target_to_load = abs_path
        elif os.path.exists(bak_path):
            print(f'[WARN] Main data file missing, recovering from {bak_path}')
            target_to_load = bak_path
        if not target_to_load:
            return
        with state.lock:
            data = None
            try:
                with open(target_to_load, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except Exception as e:
                print(f'[WARN] Error loading {target_to_load}: {e}')
                if target_to_load == abs_path and os.path.exists(bak_path):
                    try:
                        print(f'[INFO] Attempting recovery from backup {bak_path}...')
                        with open(bak_path, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                    except Exception as e2:
                        print(f'[ERROR] Backup recovery also failed: {e2}')
            if not data:
                return
            now = time.time()
            for r_id, r in data.get('rooms', {}).items():
                state.rooms[r_id] = {'name': r.get('name', 'Room'), 'owner': r.get('owner', ''), 'mode': r.get('mode', 'live'), 'ready': r.get('ready', True), 'restoreEpoch': r.get('restoreEpoch', 0), 'owner_name': r.get('owner_name', ''), 'revision': int(r.get('revision', 1)), 'objects': r.get('objects', {}), 'tombstones': r.get('tombstones', {}), 'presence': {}, 'persistent': r.get('persistent', True), 'closed': r.get('closed', False), 'members': set(r.get('members', [])), 'chat': list(r.get('chat', [])), 'last_saved': r.get('last_saved', now), 'updated_at': r.get('updated_at', now)}
            state.guests.update(data.get('guests', {}))
            state.last_disk_save_time = data.get('saved_at', now)
            total_objs = sum((len(r['objects']) for r in state.rooms.values()))
            print(f'[INFO] Loaded {len(state.rooms)} rooms ({total_objs} objects) and {len(state.guests)} guests from {target_to_load}')
    state.load_data = load_data
