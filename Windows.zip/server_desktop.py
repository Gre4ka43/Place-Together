"""Native desktop controls for the existing PlaceTogether HTTP server."""
from collections import deque
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime
from pathlib import Path
import ipaddress
import os
import queue
import re
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from placetogether_server.application import create_application


def network_addresses():
    addresses = dict((address, name) for name, address in create_application().discover_ipv4())
    if sys.platform == 'darwin':
        command = ['/sbin/ifconfig', '-a']
    elif sys.platform.startswith('linux'):
        command = ['ip', '-o', '-4', 'address', 'show', 'up']
    else:
        command = None
    if command:
        try:
            output = subprocess.check_output(command, text=True, timeout=5)
            interface = 'Network'
            for line in output.splitlines():
                if sys.platform == 'darwin' and line and not line[0].isspace():
                    interface = line.split(':', 1)[0]
                elif sys.platform.startswith('linux'):
                    interface = line.split()[1].split('@')[0]
                match = re.search(r'\binet\s+(\d+\.\d+\.\d+\.\d+)', line)
                if match:
                    address = ipaddress.IPv4Address(match[1])
                    if not address.is_loopback and not address.is_link_local:
                        addresses[str(address)] = interface
        except (OSError, subprocess.SubprocessError, ValueError, IndexError):
            pass
    return [('Этот компьютер', '127.0.0.1')] + sorted(
        (name, address) for address, name in addresses.items()
    )


class ServerSession:
    def __init__(self, port, data_path, password):
        state = self.state = create_application()
        state.data_filepath = str(data_path)
        state.backups_dir = state.get_backups_dir(state.data_filepath)
        state.auth_secret = password

        class DesktopHTTPServer(state.ConcurrentServer):
            daemon_threads = False

        class DesktopHandler(state.StudioRequestHandler):
            protocol_version = 'HTTP/1.0'

        # Bind before loading the database so a conflicting server never writes it.
        self.http = DesktopHTTPServer(('0.0.0.0', port), DesktopHandler)
        try:
            state.load_data(state.data_filepath)
        except Exception:
            self.http.server_close()
            raise
        self.stop_event = threading.Event()
        self.autosaver = state.start_autosaver(self.stop_event)
        self.thread = threading.Thread(target=self.http.serve_forever, daemon=True)
        self.thread.start()
        self.listening = True
        print(f'[INFO] Server started on port {self.http.server_port}')

    def stop(self):
        if self.listening:
            self.http.shutdown()
            self.http.server_close()
            self.thread.join()
            self.stop_event.set()
            self.autosaver.join()
            self.listening = False
        if self.state.dirty_flag and not self.state.save_data(force=True):
            raise OSError('Не удалось сохранить комнаты. Проверьте доступ к папке и повторите остановку.')
        print('[INFO] Server stopped')


class LogStream:
    encoding = 'utf-8'

    def __init__(self):
        self.pending = deque(maxlen=10000)
        self.lock = threading.Lock()

    def write(self, text):
        with self.lock:
            self.pending.append(text)
        return len(text)

    def flush(self):
        pass

    def drain(self):
        with self.lock:
            text = ''.join(self.pending)
            self.pending.clear()
        return text


class Desktop:
    def __init__(self, root, stream):
        self.root, self.stream = root, stream
        self.session = None
        self.busy = False
        self.closing = False
        self.results = queue.Queue()
        self.adapters = []
        self.port = tk.StringVar(value='8787')
        self.password = tk.StringVar(value=os.environ.get('PT_SECRET', ''))
        if getattr(sys, 'frozen', False) and sys.platform != 'win32':
            folder = Path.home() / ('Library/Application Support/PlaceTogether' if sys.platform == 'darwin' else '.local/share/PlaceTogether')
        else:
            folder = Path(sys.executable if getattr(sys, 'frozen', False) else __file__).resolve().parent
        self.data_path = tk.StringVar(value=os.environ.get('PT_DESKTOP_DATA', str(folder / 'data.json')))
        self.status = tk.StringVar(value='Сервер остановлен')
        root.title('PlaceTogether Server')
        root.geometry('860x660')
        root.minsize(720, 610)
        style = ttk.Style(root)
        style.theme_use('clam')
        background, surface = '#f1f5f9', '#ffffff'
        ink, muted, accent = '#172338', '#52647b', '#2459df'
        root.configure(background=background)
        style.configure('.', background=background, foreground=ink, font=('TkDefaultFont', 10))
        style.configure('Card.TFrame', background=surface)
        style.configure('Card.TLabel', background=surface)
        style.configure('Hint.TLabel', background=surface, foreground=muted)
        style.configure('Status.TLabel', foreground=accent, font=('TkDefaultFont', 10, 'bold'))
        style.configure('TEntry', fieldbackground='#f4f7fc', padding=(8, 7), foreground=ink)
        style.map('TEntry', fieldbackground=[('readonly', '#eef3ff')], foreground=[('readonly', ink)])
        style.configure('TCombobox', padding=(7, 5))
        style.map('TCombobox', fieldbackground=[('readonly', '#f4f7fc')])
        style.configure('TButton', background='#e5edfc', foreground=ink, padding=(14, 8), borderwidth=0)
        style.map('TButton', background=[('active', '#d5e3fc')], foreground=[('disabled', muted)])
        style.configure('Accent.TButton', background=accent, foreground='white')
        style.map('Accent.TButton', background=[('disabled', '#d5dfef'), ('active', '#1746bf')],
                  foreground=[('disabled', muted)])
        style.configure('TNotebook', borderwidth=0)
        style.configure('TNotebook.Tab', padding=(20, 10), background=background, foreground=muted)
        style.map('TNotebook.Tab', background=[('selected', surface)], foreground=[('selected', accent)])

        shell = ttk.Frame(root, padding=(24, 18))
        shell.pack(fill='both', expand=True)
        header = ttk.Frame(shell)
        header.pack(fill='x', pady=(0, 14))
        ttk.Label(header, text='PlaceTogether', font=('TkDefaultFont', 22, 'bold')).pack(anchor='w')
        ttk.Label(header, text='Сервер для совместной работы в Roblox Studio', foreground=muted).pack(anchor='w')
        tabs = ttk.Notebook(shell)
        tabs.pack(fill='both', expand=True)
        home = ttk.Frame(tabs, padding=(0, 12, 0, 0))
        logs = ttk.Frame(tabs, padding=(0, 12, 0, 0))
        settings = ttk.Frame(tabs, padding=(0, 12, 0, 0))
        tabs.add(home, text='Подключение')
        tabs.add(logs, text='Логи')
        tabs.add(settings, text='Настройки')

        launch = ttk.Frame(home, style='Card.TFrame', padding=16)
        launch.pack(fill='x', pady=(0, 12))
        ttk.Label(launch, text='1. Запусти сервер', style='Card.TLabel',
                  font=('TkDefaultFont', 14, 'bold')).pack(anchor='w')
        ttk.Label(launch, textvariable=self.status, style='Status.TLabel',
                  background=surface).pack(anchor='w', pady=(4, 10))
        controls = ttk.Frame(launch, style='Card.TFrame')
        controls.pack(fill='x')
        self.start_button = ttk.Button(controls, text='Запустить', command=self.start, style='Accent.TButton')
        self.start_button.pack(side='left')
        self.stop_button = ttk.Button(controls, text='Остановить', command=self.stop, state='disabled')
        self.stop_button.pack(side='left', padx=(8, 0))

        connection = ttk.Frame(home, style='Card.TFrame', padding=16)
        connection.pack(fill='x')
        ttk.Label(connection, text='2. Подключись из Studio', style='Card.TLabel',
                  font=('TkDefaultFont', 14, 'bold')).pack(anchor='w')
        ttk.Label(connection, text='Открой PlaceTogether → Settings и заполни IP / Host и Port.',
                  style='Hint.TLabel').pack(anchor='w', pady=(4, 12))
        fields = ttk.Frame(connection, style='Card.TFrame')
        fields.pack(fill='x')
        fields.columnconfigure(0, weight=1)
        fields.columnconfigure(1, weight=1)
        self.local_host = tk.StringVar(value='127.0.0.1')
        self.friend_host = tk.StringVar()
        self.network = tk.StringVar()
        ttk.Label(fields, text='Для тебя на этом ПК', style='Card.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Label(fields, text='Для друга по сети или VPN', style='Card.TLabel').grid(row=0, column=1, sticky='w', padx=(12, 0))
        local_row = ttk.Frame(fields, style='Card.TFrame')
        local_row.grid(row=1, column=0, sticky='ew', pady=(4, 8))
        friend_row = ttk.Frame(fields, style='Card.TFrame')
        friend_row.grid(row=1, column=1, sticky='ew', padx=(12, 0), pady=(4, 8))
        self.local_address_input = self.copy_field(local_row, self.local_host)
        self.friend_address_input = self.copy_field(friend_row, self.friend_host)
        self.network_choice = ttk.Combobox(fields, textvariable=self.network, state='readonly')
        self.network_choice.grid(row=2, column=1, sticky='ew', padx=(12, 0))
        self.network_choice.bind('<<ComboboxSelected>>', self.select_network)
        port_row = ttk.Frame(fields, style='Card.TFrame')
        port_row.grid(row=2, column=0, sticky='w')
        ttk.Label(port_row, text='Port', style='Card.TLabel').pack(side='left', padx=(0, 8))
        self.port_display = self.copy_field(port_row, self.port, width=8)
        for field in (self.local_address_input, self.friend_address_input, self.port_display):
            for shortcut in ('<Control-a>', '<Command-a>') if sys.platform == 'darwin' else ('<Control-a>',):
                field.bind(shortcut, self.select_text)
        ttk.Label(connection, text='Нажми «Копировать» или выдели значение и используй Ctrl+C / ⌘C.',
                  style='Hint.TLabel').pack(anchor='w', pady=(10, 0))
        footer = ttk.Frame(home)
        footer.pack(fill='x', pady=(10, 0))
        ttk.Label(footer, text='3. Создай комнату в Studio и отправь другу её код.', foreground=muted).pack(side='left')
        ttk.Button(footer, text='Обновить адреса', command=self.refresh_addresses).pack(side='right')

        options = ttk.Frame(settings, style='Card.TFrame', padding=16)
        options.pack(fill='x')
        options.columnconfigure(1, weight=1)
        ttk.Label(options, text='Порт', style='Card.TLabel').grid(row=0, column=0, sticky='w', pady=5)
        self.port_input = ttk.Entry(options, textvariable=self.port, width=8)
        self.port_input.grid(row=0, column=1, sticky='w', padx=10)
        ttk.Label(options, text='Пароль', style='Card.TLabel').grid(row=1, column=0, sticky='w', pady=5)
        self.secret_input = ttk.Entry(options, textvariable=self.password, show='•')
        self.secret_input.grid(row=1, column=1, sticky='ew', padx=10)
        ttk.Label(options, text='Файл комнат', style='Card.TLabel').grid(row=2, column=0, sticky='w', pady=5)
        self.data_input = ttk.Entry(options, textvariable=self.data_path)
        self.data_input.grid(row=2, column=1, sticky='ew', padx=10)
        self.pick_button = ttk.Button(options, text='Выбрать…', command=self.pick_data)
        self.pick_button.grid(row=2, column=2)
        ttk.Label(options, text='Если задашь пароль, введи его в Settings плагина на обоих ПК.',
                  style='Hint.TLabel').grid(row=3, column=0, columnspan=3, sticky='w', pady=(10, 0))

        log_header = ttk.Frame(logs, style='Card.TFrame', padding=12)
        log_header.pack(fill='x', pady=(0, 8))
        ttk.Label(log_header, text='Журнал сервера', style='Card.TLabel',
                  font=('TkDefaultFont', 13, 'bold')).pack(side='left')
        ttk.Button(log_header, text='Экспорт TXT…', command=self.export_logs, style='Accent.TButton').pack(side='right')
        ttk.Label(log_header, text='Последние 10 000 строк', style='Hint.TLabel').pack(side='right', padx=12)
        self.log = tk.Text(logs, wrap='word', state='disabled', font='TkFixedFont',
                           background='#152239', foreground='#e3edfc', selectbackground=accent,
                           borderwidth=0, padx=14, pady=12)
        scroll = ttk.Scrollbar(logs, orient='vertical', command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        scroll.pack(side='right', fill='y')
        self.log.pack(fill='both', expand=True)
        self.render_addresses()
        self.refresh_addresses()
        root.protocol('WM_DELETE_WINDOW', self.close)
        root.after(100, self.update)

    def copy_field(self, parent, variable, width=17):
        field = ttk.Entry(parent, textvariable=variable, state='readonly', width=width, exportselection=False)
        field.pack(side='left', fill='x', expand=True)
        ttk.Button(parent, text='Копировать', command=lambda: self.copy_value(variable.get())).pack(
            side='left', padx=(6, 0))
        field.bind('<Control-KeyPress>', self.copy_on_control)
        return field

    def copy_value(self, value):
        if value:
            self.root.clipboard_clear()
            self.root.clipboard_append(value)

    @staticmethod
    def copy_on_control(event):
        if event.keysym.lower() in ('c', 'cyrillic_es') or (sys.platform == 'win32' and event.keycode == 67):
            event.widget.event_generate('<<Copy>>')
            return 'break'

    def pick_data(self):
        path = filedialog.askopenfilename(filetypes=[('Данные PlaceTogether', '*.json'), ('Все файлы', '*')])
        if path:
            self.data_path.set(path)

    def refresh_addresses(self):
        def discover():
            self.results.put(('addresses', network_addresses(), None))
        threading.Thread(target=discover, daemon=True).start()

    def render_addresses(self):
        previous = self.friend_host.get()
        self.friend_adapters = [(name, address) for name, address in self.adapters if address != '127.0.0.1']
        if not self.friend_adapters:
            self.network_choice.configure(values=('Сетевой адрес не найден',), state='disabled')
            self.network_choice.current(0)
            self.friend_host.set('')
            return
        labels = [f'{name} · {address}' for name, address in self.friend_adapters]
        self.network_choice.configure(values=labels, state='readonly')
        selected = next((i for i, (_, address) in enumerate(self.friend_adapters) if address == previous), 0)
        self.network_choice.current(selected)
        self.select_network()

    def select_network(self, event=None):
        index = self.network_choice.current()
        if 0 <= index < len(self.friend_adapters):
            self.friend_host.set(self.friend_adapters[index][1])

    @staticmethod
    def select_text(event):
        event.widget.selection_range(0, 'end')
        event.widget.icursor('end')
        return 'break'

    def run_operation(self, action, callback, status):
        self.busy = True
        self.status.set(status)
        self.sync_controls()

        def run():
            try:
                self.results.put((action, callback(), None))
            except Exception as error:
                print(f'[ERROR] {error}', file=sys.stderr)
                self.results.put((action, None, str(error)))
        threading.Thread(target=run, daemon=True).start()

    def start(self):
        try:
            port = int(self.port.get())
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            messagebox.showerror('Порт', 'Введите номер порта от 1 до 65535.')
            return
        if not self.data_path.get().strip():
            messagebox.showerror('Данные', 'Укажите путь к файлу данных.')
            return
        path = Path(self.data_path.get()).expanduser().resolve()
        password = self.password.get()

        def launch():
            path.parent.mkdir(parents=True, exist_ok=True)
            return ServerSession(port, path, password)
        self.run_operation('start', launch, 'Запуск сервера…')

    def stop(self):
        self.run_operation('stop', self.session.stop, 'Остановка и сохранение данных…')

    def sync_controls(self):
        editable = 'normal' if not self.busy and not self.session else 'disabled'
        for widget in (self.port_input, self.secret_input, self.data_input, self.pick_button, self.start_button):
            widget.configure(state=editable)
        self.stop_button.configure(state='normal' if self.session and not self.busy else 'disabled')

    def read_logs(self):
        text = self.stream.drain()
        if text:
            at_bottom = self.log.yview()[1] >= 0.99
            self.log.configure(state='normal')
            self.log.insert('end', text)
            lines = int(self.log.index('end-1c').split('.')[0])
            if lines > 10000:
                self.log.delete('1.0', f'{lines - 9999}.0')
            self.log.configure(state='disabled')
            if at_bottom:
                self.log.see('end')

    def export_logs(self):
        path = filedialog.asksaveasfilename(
            defaultextension='.txt', filetypes=[('Текстовый файл', '*.txt')],
            initialfile=datetime.now().strftime('PlaceTogether-%Y%m%d-%H%M%S.txt'),
        )
        if path:
            self.read_logs()
            try:
                Path(path).write_text(self.log.get('1.0', 'end-1c'), encoding='utf-8')
            except OSError as error:
                messagebox.showerror('Экспорт логов', str(error))

    def update(self):
        self.read_logs()
        while not self.results.empty():
            action, value, error = self.results.get_nowait()
            if action == 'addresses':
                self.adapters = value
                self.render_addresses()
                continue
            self.busy = False
            if error:
                self.closing = False
                self.status.set('Ошибка запуска' if action == 'start' else 'Ошибка сохранения при остановке')
                messagebox.showerror('PlaceTogether Server', error)
            elif action == 'start':
                self.session = value
                self.status.set(f'Сервер работает · порт {value.http.server_port}')
            else:
                self.session = None
                self.status.set('Сервер остановлен')
            self.sync_controls()
            if self.closing:
                self.close()
                return
        self.root.after(100, self.update)

    def close(self):
        self.closing = True
        if self.busy:
            return
        if self.session:
            self.stop()
        else:
            self.root.destroy()


def main():
    root = tk.Tk()
    stream = LogStream()
    with redirect_stdout(stream), redirect_stderr(stream):
        Desktop(root, stream)
        if sys.argv[1:] == ['--smoke-test']:
            root.withdraw()
            root.update_idletasks()
            root.destroy()
            return
        root.mainloop()


if __name__ == '__main__':
    main()
