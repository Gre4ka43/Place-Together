@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul 2>&1
set "PYTHONIOENCODING=utf-8"
title PlaceTogether Studio 6.1 Server
set "SRV=%~dp0server.py"
set "EXE=%~dp0PlaceTogetherServer.exe"
set "DATA=%~dp0data.json"
if not "%~1"=="" set "PT_SECRET=%~1"
echo.
echo PlaceTogether Studio 6.1
echo Local dashboard: http://127.0.0.1:8787
echo Data: %DATA%
echo Backups: %~dp0backups
echo.
if defined PT_SECRET (echo Server password: enabled) else (echo Server password: not set)
powershell -NoProfile -Command "Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notmatch '^127\.|^169\.254\.' } | Select-Object InterfaceAlias,IPAddress | Format-Table -AutoSize"
echo If LAN/VPN clients cannot connect, allow inbound TCP port 8787 in Windows Firewall.
echo Stop the previous server before starting this version. Ctrl+C stops the server.
echo.
if not exist "%SRV%" goto standalone
python --version >nul 2>&1
if not errorlevel 1 goto python
py -3 --version >nul 2>&1
if not errorlevel 1 goto pylauncher
if exist "%~dp0python_embed\python.exe" goto embedded
:standalone
if not exist "%EXE%" goto missing
"%EXE%" --port 8787 --data "%DATA%"
goto finished
:python
python "%SRV%" --port 8787 --data "%DATA%"
goto finished
:pylauncher
py -3 "%SRV%" --port 8787 --data "%DATA%"
goto finished
:embedded
"%~dp0python_embed\python.exe" "%SRV%" --port 8787 --data "%DATA%"
goto finished
:missing
echo ERROR: Install Python 3 or keep PlaceTogetherServer.exe in this folder.
pause
exit /b 1
:finished
set "SERVER_EXIT=%errorlevel%"
echo.
echo Server stopped. Exit code: %SERVER_EXIT%
pause
exit /b %SERVER_EXIT%
