"""Run with Python 3.12+ and PyInstaller on the target operating system."""
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
mode = '--onedir' if sys.platform == 'darwin' else '--onefile'
subprocess.run([
    sys.executable, '-m', 'PyInstaller', '--noconfirm', '--windowed', mode,
    '--name', 'PlaceTogetherServerDesktop', '--distpath', str(root / 'desktop-dist'),
    '--workpath', str(root / 'desktop-build'), '--specpath', str(root / 'desktop-build'),
    str(root / 'server_desktop.py'),
], check=True)
