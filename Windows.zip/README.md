# PlaceTogether Server для Windows

Распакуй архив и запусти PlaceTogetherServerDesktop.exe. Python не нужен.
Откроется окно без консоли. Нажми «Запустить сервер».
PlaceTogetherServer.exe и StartPlaceTogetherServer.bat оставлены для старого консольного запуска.
Для плагина Studio используй InstallPlugin.bat.

На вкладке «Подключение» есть шаги запуска и поля IP / Host и Port для плагина.
Адрес можно выделить мышью и скопировать стандартным сочетанием клавиш.
Для друга выбери нужную сеть или VPN в списке. Экспорт TXT находится во вкладке «Логи».
При переносе комнат укажи путь к своему data.json. Останови прежний сервер перед использованием того же файла.
На Linux и macOS можно собрать автономное приложение на целевой системе.
Установи PyInstaller для Python 3.12+ и выполни python3 source/build_server_desktop.py.
Результат появится в desktop-dist. Windows проверен. Запуск на Linux и macOS не проверен.
