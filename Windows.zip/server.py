"""PlaceTogether Studio 6.1 server entry point."""
from placetogether_server.application import run

if __name__ == "__main__":
    run()
